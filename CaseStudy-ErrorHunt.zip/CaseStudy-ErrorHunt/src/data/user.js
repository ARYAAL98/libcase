var users=[{
    "id":1,
    "uid":"aiswaryawalter@gmail.com",
    "pwd":"aiswarya"
},
{
    "id":2,
    "uid":"surya@gmail.com",
    "pwd":"surya"
},
{
    "id":3,
    "uid":"bazith@gmail.com",
    "pwd":"bazith"
}
]


module.exports=user;